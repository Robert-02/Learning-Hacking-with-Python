monthConversions = {
    "Jan": "January",
    "Feb": "February",
    "Mar": "March",
    "May": "May",
    "Jun": "June",
    "Jul": "July",
    "Aug": "August",
    "Sep": "September",
    "Oct":  "October",
    "Nov": "November",
    "Dec": "December",
}

print(monthConversions.get("Luv","Not a valid Key"))
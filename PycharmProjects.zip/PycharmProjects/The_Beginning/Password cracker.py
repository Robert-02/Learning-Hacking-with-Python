from random import randint
user_input = input("Enter your password:")
password = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k',
            'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v']
guess = ""
while guess != user_input:
    guess = ""
    for letter in range(len(user_input)):
        guess_letter = password[randint(0, 10)]
        guess = str(guess_letter) + str(guess)
    print(guess)
print(guess)

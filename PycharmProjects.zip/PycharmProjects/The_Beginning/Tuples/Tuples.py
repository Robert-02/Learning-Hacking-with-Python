coordonates = [(4,5),(6,7),(80,34)]
coordonates[1] = 10 #tuples are immutable
print(coordonates[1])

friends = ["Kevin","Karen","Jim","Oscar","Toby"] # the lists are mutable
print(friends)
print(friends.index("Karen"))
print(friends[0])
print(friends[-1])
print(friends[1:])
print(friends[1:3])
friends[1] = "Mike"
print(friends[1])
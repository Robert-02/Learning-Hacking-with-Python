def cube(num):
    return num*num*num
print("code")
print(cube(3))
result = cube(4)
print(result)
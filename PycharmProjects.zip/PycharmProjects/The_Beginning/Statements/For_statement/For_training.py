
friends = ["Jim","Karen","Kevin"]

#for letter in "Giraffe Academy":
#   print(letter)
#for friend in friends:
#   print(friend)
#for index in range(10):
#for index in range(len(friends)):
for index in range(5):
    if index == 0:
        print("first Itineration")
    else:
        print("Not first")
    #print(friends[index])


def say_hi(name):
    print("Hello " + name)

#print("Top")
#say_hi()
#print("Bottom")
say_hi("Mike")
say_hi("Steve")
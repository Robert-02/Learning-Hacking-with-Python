import socket

def port_scanner(host, start_port, end_port):
    for port in range(start_port, end_port + 1):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)

        try:
            sock.connect((host, port))
            print(f"Port {port} is open")
        except socket.error:
            # Port is closed
            pass
        finally:
            sock.close()

if __name__ == "__main__":
    target_host = "127.0.0.1"
    start_port = 1
    end_port = 1024

    port_scanner(target_host, start_port, end_port)

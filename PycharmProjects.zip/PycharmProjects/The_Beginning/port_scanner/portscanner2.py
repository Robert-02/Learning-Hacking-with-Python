import socket


class PortScanner:
    def __init__(self, host, start_port, end_port):
        self.host = host
        self.start_port = start_port
        self.end_port = end_port

    def scan(self):
        for port in range(self.start_port, self.end_port+1):
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(4)
            try:
                sock.connect((self.host, port))
                print(f"The port {port} is open")
            except socket.error:
                pass
            finally:
                sock.close()

if __name__ == "__main__":
    server = PortScanner("127.0.0.1", 8080, 4433)
    server.scan()
import socket

port = 12345  # Use a port number greater than 1024
ip_address = '0.0.0.0'  # Bind to all available network interfaces

socket_server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
socket_server.bind((ip_address, port))

def buildresponse(data):
    # Your response building logic here
    TransactionID = data[:2]
    TID = ''
    for byte in TransactionID:
        TID += (hex(byte))[2:]

    flags = getflags(data[2:4])
while True:
    data, addr = socket_server.recvfrom(512)
    r = buildresponse(data)
    socket_server.sendto(r, addr)

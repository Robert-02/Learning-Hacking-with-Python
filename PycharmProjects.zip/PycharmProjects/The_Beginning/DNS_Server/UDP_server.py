import socket

port = 53
ip = '192.168.1.8'

sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
sock.bind((ip, port))

def buildresponse(data):
    transaction_id= data[:2]

    print(transaction_id)

    for byte in transaction_id:
        print(byte)


while 1:
    data, addr = sock.recvfrom(512)
    r = buildresponse(data)
    sock.sendto(r, addr)

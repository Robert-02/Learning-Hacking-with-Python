from http.server import HTTPServer, BaseHTTPRequestHandler
host = '192.168.1.8'
port = 9999

class NeuralHTTP(BaseHTTPRequestHnadler):
    def do_get(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()

        self.wfile.write(bytes("<html><body><h1>HELLO WORLD!</h1></body></html>"))

    server = HTTPServer((host, port), NeuralHTTP)
    print("Server now running...")
    server.serve_forever()
    server.server_close()

    print("Server stopped! ")
import socket
host = '192.168.1.8'
port = 9090

socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket.connect((host, port))

socket.send("Hello world!".encode('utf-8'))
print(socket.recv(1024))

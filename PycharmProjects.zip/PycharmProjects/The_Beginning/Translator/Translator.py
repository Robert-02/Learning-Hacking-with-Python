def translate_consonants(phrase):
    translation = ""
    for letter in phrase:
        if letter in "AEIOUaeiou":
            if letter.lower() in "aeiou":
                if letter.isupper():
                    translation = translation + "g"
                else:
                    translation = translation + letter
                return translation
print(translate_consonants(input("Enter a phrase:")))
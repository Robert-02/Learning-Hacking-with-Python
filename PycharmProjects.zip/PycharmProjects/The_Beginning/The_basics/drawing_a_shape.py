print("/___|")
print("   /|")
print("  / |")
print(" /  |")

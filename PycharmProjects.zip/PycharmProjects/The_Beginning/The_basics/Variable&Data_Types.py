character_name = "Tom"
character_age = 50  
isMale = False

print("There once was a man named " + character_name +",")
print("he was " + character_age + "  years old.")

character_name = "Mike"
print("He really liked the name " + character_name + ",")
print("but didn't like being " + character_age + ".")

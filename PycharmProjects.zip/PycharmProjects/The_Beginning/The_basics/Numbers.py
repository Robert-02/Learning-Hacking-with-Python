from math import floor, ceil, sqrt

print(-2.0987)
print(3+4)
print(3+4.5)
print(3*(4+5))
print(3+4*5)
print(10%3)
my_num = -5
print(str(my_num))
print(abs(my_num))
print(pow(2,3))
print(max(2,3))
print(min(2,3))
print(round(3.2))
print(floor(3.6))
print(ceil(3.7))
print(sqrt(4))
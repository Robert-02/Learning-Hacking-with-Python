
phrase = "Girrafe Academy"
print(phrase)
print(phrase.upper())
print(phrase.lower())
print(phrase.isupper())
print(phrase.upper().isupper())
print(len(phrase))
print(phrase[0])
print(phrase[3])
print(phrase.index("G"))
print(phrase.replace("Girrafe","Elephant"))
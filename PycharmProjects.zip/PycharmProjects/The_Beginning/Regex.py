url = "http://olympus.realpython.org/profiles/aphrodite"
page = urlopen(url)
html_byes = page.read()
html = html_byes.decode('utf-8')
answer = 50
guess_count = 3
while True:
  question = int(input("Introduceti un numar: "))
  if question < answer:
    print("You lose")
  elif question > answer:
    print("You win")
  else:
    print("Felicitari! Ati ghicit numarul.")
    break

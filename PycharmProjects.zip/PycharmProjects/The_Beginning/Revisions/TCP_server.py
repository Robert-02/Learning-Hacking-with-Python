import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = "127.0.0.1"
port = 8080
sock.bind((host, port))
sock.listen(5)
while True:
    client, addr = sock.accept()
    print("Thanks for receiving the message")
    message = "Connected sucessfully to the server\r\n"
    client.send(message.encode())
    client.close()
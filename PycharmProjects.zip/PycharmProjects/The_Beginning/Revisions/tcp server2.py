import socket

class TCPServer:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def bind(self):
        self.sock.bind((self.host, self.port))
        self.sock.listen(5)

    def handle_connection(self):
        client, addr = self.sock.accept()
        print("Thank you for receiving the message")
        message = "Connected successfully to the server"
        client.send(message.encode())
        client.close()

    def close(self):
        self.sock.close()

class PortScanner:
    def __init__(self, host, ports):
        self.host = host
        self.ports = ports

    def port_verify(self):
        all_ports_closed = True
        for port in self.ports:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)  # Adjust the timeout based on your needs

            try:
                result = sock.connect_ex((self.host, port))
                if result == 0:
                    print(f"Port {port} is open")
                    all_ports_closed = False
            except socket.error:
                print(f"Error checking port {port}")

            sock.close()

        if all_ports_closed:
            print("All ports in the list are closed")
#port_scanner = PortScanner("localhost", [80, 1234, 2000, 433])
#port_scanner.port_verify()

# Start the TCPServer
#tcp_server = TCPServer("127.0.0.1", 8080)
#tcp_server.bind()
#tcp_server.handle_connection()
#tcp_server.close()

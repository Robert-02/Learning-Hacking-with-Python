import socket
import threading


def port_scan(target, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((target, port))
    print(f"Port {port} is open")

    # Close the socket
    sock.close()
except socket.error:
    pass
def scan_target(target, port):
    print(f"Scanning target {target_ip}...")
    threads=[]
    for port in port_scan():
        thread = threading.Thread(target = port_scan, args=(target, port))
        threads.append(thread)
        thread.start()
    for thread in threads:
        thread.join()

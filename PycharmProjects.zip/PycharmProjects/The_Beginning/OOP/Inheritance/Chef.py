class Chef:
    def make_chicken(self):
        print("The chief makes a chicken")

    def make_salad(self):
        print("The chief makes a salad")

    def make_special_dish(self):
        print("The chief makes a bbq ribs")

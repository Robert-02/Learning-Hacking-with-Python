from Chef import Chef
from ChineseChef import ChineseChef

myChef = Chef()
myChef.make_chicken()

myChineseChef = ChineseChef()
myChineseChef.make_special_dish()

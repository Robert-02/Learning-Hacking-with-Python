class myClass:
    a = 10
    def display(self):
        print(self.a)
obj = myClass()
obj.display()



print(myClass.a)